## Packages
(none needed - using base stack and pre-installed packages like react-hook-form, zod, framer-motion)

## Notes
- The application uses `api.leads.create` for capturing emails.
- UI components (Button, Dialog, Input, Progress, Form) are assumed to be standard Shadcn UI from `@/components/ui/`.
- Styling uses a custom 'Obsidian', 'Ghost White', and 'Liberty Gold' theme implemented via CSS variables.
