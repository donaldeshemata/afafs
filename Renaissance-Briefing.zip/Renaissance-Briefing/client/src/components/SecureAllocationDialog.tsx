import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { ShieldAlert, Lock, CheckCircle2, ChevronRight } from "lucide-react";
import { api, type LeadInput } from "@shared/routes";
import { useCreateLead } from "@/hooks/use-leads";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface Props {
  children: React.ReactNode;
}

export function SecureAllocationDialog({ children }: Props) {
  const [open, setOpen] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const createLead = useCreateLead();

  const form = useForm<LeadInput>({
    resolver: zodResolver(api.leads.create.input),
    defaultValues: {
      email: "",
    },
  });

  const onSubmit = async (data: LeadInput) => {
    try {
      await createLead.mutateAsync(data);
      setIsSuccess(true);
    } catch (err) {
      // Error handled by hook toast
    }
  };

  const handleOpenChange = (newOpen: boolean) => {
    setOpen(newOpen);
    if (!newOpen) {
      // Reset form on close after a small delay
      setTimeout(() => {
        setIsSuccess(false);
        form.reset();
      }, 300);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md border-white/10 bg-[#0a0a0a] text-white shadow-2xl shadow-red-900/20">
        {!isSuccess ? (
          <>
            <DialogHeader className="space-y-4">
              <div className="mx-auto w-12 h-12 bg-red-500/10 rounded-full flex items-center justify-center border border-red-500/20">
                <ShieldAlert className="w-6 h-6 text-red-500" />
              </div>
              <DialogTitle className="text-center text-2xl font-bold uppercase tracking-wider text-white font-display">
                Secure Your Position
              </DialogTitle>
              <DialogDescription className="text-center text-zinc-400">
                The window for the Patriot Golden Bar Liberty Edition is closing. Enter your secure communication channel to receive your allocation brief.
              </DialogDescription>
            </DialogHeader>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 mt-4">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-zinc-300 font-mono text-xs uppercase tracking-wider flex items-center gap-2">
                        <Lock className="w-3 h-3 text-gold" /> Secure Comms (Email)
                      </FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="patriot@protonmail.com" 
                          className="bg-black border-white/20 text-white placeholder:text-zinc-600 focus-visible:ring-gold h-12"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage className="text-red-400" />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  disabled={createLead.isPending}
                  className="w-full h-14 text-base font-bold bg-primary hover:bg-primary/90 text-white transition-all uppercase tracking-wider glow-red group"
                >
                  {createLead.isPending ? "Encrypting Request..." : "Request Allocation Status"}
                  <ChevronRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
                
                <p className="text-center text-[10px] text-zinc-600 font-mono mt-4 uppercase tracking-widest">
                  End-to-End Encrypted Transmission
                </p>
              </form>
            </Form>
          </>
        ) : (
          <div className="py-8 flex flex-col items-center justify-center space-y-6 text-center">
            <div className="w-20 h-20 bg-green-500/10 rounded-full flex items-center justify-center border border-green-500/20 mb-2">
              <CheckCircle2 className="w-10 h-10 text-green-500" />
            </div>
            <DialogTitle className="text-2xl font-bold uppercase tracking-wider text-white font-display">
              Request Received
            </DialogTitle>
            <p className="text-zinc-400 max-w-sm">
              Your priority allocation status has been logged in the private ledger. Check your secure comms (email) immediately for next steps.
            </p>
            <Button 
              variant="outline" 
              onClick={() => handleOpenChange(false)}
              className="mt-6 border-white/20 text-white hover:bg-white/10 w-full"
            >
              CLOSE SECURE CHANNEL
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
