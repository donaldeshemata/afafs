import { AlertCircle, ArrowRight, Play, ShieldCheck, Lock, Globe, FileText, CircleCheck, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { SecureAllocationDialog } from "@/components/SecureAllocationDialog";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col font-sans selection:bg-gold selection:text-black overflow-x-hidden">
      
      {/* Sticky Tactical Nav */}
      <nav className="fixed top-0 w-full z-50 glass-dark">
        <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-gold opacity-80" />
            <span className="font-mono text-xs text-zinc-400 uppercase tracking-widest hidden sm:inline-block">
              Encrypted Channel // SECURE
            </span>
          </div>
          <div className="flex items-center gap-3 bg-red-950/30 border border-red-900/50 px-3 py-1.5 rounded-sm">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
            </span>
            <span className="text-xs font-mono font-bold text-red-500 uppercase tracking-widest">
              Live Inventory: Low
            </span>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 px-4 flex flex-col items-center justify-center text-center border-b border-white/10">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-zinc-800/40 via-black to-black -z-10"></div>
        
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="inline-flex items-center gap-2 border border-gold/30 bg-gold/5 px-4 py-1.5 rounded-full mb-4 glow-gold">
            <ShieldCheck className="w-4 h-4 text-gold" />
            <span className="text-gold font-mono text-xs uppercase tracking-widest font-semibold">
              Global Transition Notice: Phase 1 Active
            </span>
          </div>
          
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-display font-black text-white leading-[1.1] uppercase tracking-tight">
            YOUR ESCAPE HATCH: <br className="hidden md:block"/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-gold via-yellow-200 to-gold">
              24K GOLD XRP BARS
            </span>
          </h1>
          
          <p className="text-lg md:text-xl text-zinc-400 max-w-2xl mx-auto font-medium leading-relaxed">
            These aren't ordinary bars. They're Wealth Preservation Assets—your guaranteed entry pass to the new debt-free financial system using XRP & Pure Gold.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-8">
            <SecureAllocationDialog>
              <Button className="w-full sm:w-auto h-16 px-8 text-sm md:text-base font-bold bg-primary hover:bg-primary/90 text-white transition-all uppercase tracking-widest animate-tactical-pulse">
                Secure Your Physical Allocation
              </Button>
            </SecureAllocationDialog>
            <Button variant="outline" className="w-full sm:w-auto h-16 px-8 text-sm md:text-base font-bold border-white/20 text-white hover:bg-white/5 transition-all uppercase tracking-widest bg-transparent">
              View Transition Strategy
            </Button>
          </div>
        </div>
      </section>

      {/* Paper-White Narrative Section */}
      <section className="paper-theme bg-background text-foreground py-24 px-4 relative">
        {/* Subtle grid pattern for the "paper" */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none"></div>
        
        <div className="max-w-3xl mx-auto relative z-10 space-y-12">
          
          <div className="space-y-6 text-lg md:text-xl leading-relaxed text-zinc-800">
            <p className="font-semibold text-xl md:text-2xl text-black">
              Dear Patriot,
            </p>
            <p>
              The old system is built on debt and illusion. You've seen the signs—inflation spiraling, central banks printing trillions out of thin air, and a coordinated push toward absolute control via Central Bank Digital Currencies (CBDCs).
            </p>
            <p>
              What they aren't telling you on the evening news is that the <strong className="text-black bg-gold/20 px-1">Global Financial Reset (NESARA/GESARA)</strong> is no longer a theory. It is an active, ongoing operation.
            </p>
          </div>

          {/* Testimonial Blockquote */}
          <blockquote className="my-12 border-l-4 border-gold bg-white p-8 italic text-xl md:text-2xl font-serif text-black shadow-[0_8px_30px_rgb(0,0,0,0.04)] rounded-r-lg relative">
            <div className="absolute top-4 left-4 text-gold opacity-20 text-6xl font-serif leading-none">"</div>
            <p className="relative z-10">
              "Since securing our physical allocation, my family finally feels safe from the upcoming transition. We are no longer at the mercy of the banking grid."
            </p>
            <footer className="text-sm font-sans font-bold text-zinc-500 mt-4 not-italic uppercase tracking-widest">
              — Verified Sovereign Holder, TX
            </footer>
          </blockquote>

          <div className="space-y-6 text-lg md:text-xl leading-relaxed text-zinc-800">
            <p>
              The transition to a quantum-backed, asset-backed system requires physical, tangible proof of wealth. Gold is not merely an investment; it is your family's financial shield. 
            </p>
            <p className="font-bold text-black">
              Physical gold operates entirely outside their grid. It cannot be frozen, hacked, or erased by a central authority.
            </p>
          </div>

          {/* Video Placeholder Section */}
          <div className="mt-16 mb-8 rounded-2xl overflow-hidden bg-black border border-zinc-800 shadow-2xl shadow-black/50 group relative cursor-pointer aspect-video flex items-center justify-center">
            {/* Dark abstract background pretending to be a video thumbnail */}
            <div className="absolute inset-0 bg-gradient-to-tr from-zinc-900 via-black to-zinc-950 opacity-80"></div>
            <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg viewBox=%220 0 200 200%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cfilter id=%22noise%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.85%22 numOctaves=%223%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23noise)%22 opacity=%220.1%22/%3E%3C/svg%3E')]"></div>
            
            <div className="relative z-10 flex flex-col items-center">
              <div className="w-20 h-20 bg-red-600/90 rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(220,38,38,0.6)] group-hover:scale-110 transition-transform duration-300">
                <Play className="w-8 h-8 text-white ml-2" />
              </div>
              <p className="mt-6 font-mono font-bold text-white text-sm md:text-base uppercase tracking-widest bg-black/50 px-4 py-2 rounded border border-white/10 backdrop-blur">
                Watch: Leaked Quantum System Test
              </p>
            </div>
            
            <div className="absolute top-4 left-4 flex items-center gap-2 bg-red-600 px-2 py-1 rounded text-white text-xs font-bold uppercase tracking-wider">
              <span className="w-2 h-2 rounded-full bg-white animate-pulse"></span>
              Classified Brief
            </div>
          </div>
          
        </div>
      </section>

      {/* Dual-Column Pricing Comparison Section */}
      <section className="py-24 px-4 bg-[#050505] relative border-t border-white/5">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-display font-black text-white uppercase tracking-tight mb-4">
              The Protocol For Protection
            </h2>
            <div className="max-w-md mx-auto mb-8">
              <div className="flex justify-between text-sm font-mono uppercase tracking-wider mb-2">
                <span className="text-zinc-400">Critical Stock Level</span>
                <span className="text-red-400 font-bold">92% Filled</span>
              </div>
              <Progress value={92} className="h-2 bg-zinc-800" indicatorClassName="bg-gradient-to-r from-red-600 to-red-500" />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8 items-stretch">
            {/* Active Offer */}
            <div className="bg-[#0a0a0a] rounded-2xl border-2 border-green-500 shadow-[0_0_50px_rgba(34,197,94,0.1)] overflow-hidden flex flex-col">
              <div className="bg-green-600 text-white text-center py-2 text-xs font-mono font-bold uppercase tracking-widest">
                🚨 CURRENT PRICE (LAST CHANCE)
              </div>
              <div className="p-8 md:p-12 flex-1 flex flex-col">
                <div className="mb-8">
                  <div className="text-5xl md:text-6xl font-display font-black text-white mb-2">$1,399</div>
                  <div className="text-green-500 font-bold uppercase tracking-wider">For 25 Patriot 24k Gold XRP Bars + 5 Free</div>
                </div>

                <ul className="space-y-4 mb-12 flex-1">
                  {[
                    'Solid 24k Gold Investment',
                    'XRP Ledger Integrated',
                    'Direct Registration',
                    'Sovereign Asset Status',
                    'Tax-Free Classification',
                    'Available NEXT 5 DAYS ONLY'
                  ].map((item, i) => (
                    <li key={i} className="flex items-center gap-3 text-zinc-300 font-medium">
                      <CircleCheck className="w-5 h-5 text-green-500 flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>

                <SecureAllocationDialog>
                  <Button className="w-full h-16 text-lg font-bold bg-green-600 hover:bg-green-700 text-white transition-all uppercase tracking-wider glow-green group">
                    SECURE 24K GOLD XRP BARS NOW
                    <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </SecureAllocationDialog>
              </div>
            </div>

            {/* Expired Offer */}
            <div className="bg-zinc-900/50 rounded-2xl border border-zinc-800 opacity-60 flex flex-col">
              <div className="bg-zinc-800 text-zinc-400 text-center py-2 text-xs font-mono font-bold uppercase tracking-widest">
                ⛔ AFTER FEBRUARY 20
              </div>
              <div className="p-8 md:p-12 flex-1 flex flex-col">
                <div className="mb-8">
                  <div className="text-5xl md:text-6xl font-display font-black text-zinc-500 mb-2 line-through">$29,999</div>
                  <div className="text-red-500 font-bold uppercase tracking-wider">Price Increases 650%</div>
                </div>

                <ul className="space-y-4 mb-12 flex-1">
                  {[
                    'Secondary Market Only',
                    'Complex Registration',
                    'Limited Availability',
                    'Risk of Total Exclusion'
                  ].map((item, i) => (
                    <li key={i} className="flex items-center gap-3 text-zinc-500 font-medium line-through">
                      <XCircle className="w-5 h-5 text-zinc-600 flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>

                <Button disabled className="w-full h-16 text-lg font-bold bg-zinc-800 text-zinc-500 cursor-not-allowed uppercase tracking-wider">
                  REGISTRATION CLOSED
                </Button>
              </div>
            </div>
          </div>

          <div className="mt-16 text-center">
            <SecureAllocationDialog>
              <Button variant="outline" className="h-14 px-10 text-base font-bold border-white/20 text-white hover:bg-white/5 transition-all uppercase tracking-widest bg-transparent">
                SECURE YOUR VAULT POSITION
              </Button>
            </SecureAllocationDialog>
          </div>
        </div>
      </section>

      {/* Trust Footer */}
      <footer className="bg-black py-16 px-4 border-t border-white/10">
        <div className="max-w-4xl mx-auto flex flex-col items-center text-center space-y-8">
          <div className="flex items-center gap-4 text-gold opacity-50">
            <Lock className="w-5 h-5" />
            <FileText className="w-5 h-5" />
            <ShieldCheck className="w-5 h-5" />
          </div>
          
          <div className="space-y-2">
            <p className="font-mono text-zinc-500 text-sm uppercase tracking-widest">
              2026 Private Ledger // Grid-Independent Settlement
            </p>
            <p className="text-zinc-600 text-xs max-w-xl mx-auto leading-relaxed">
              Information contained herein is classified for sovereign citizens preparing for the humanitarian financial transition. Assets are subject to availability due to unprecedented global demand.
            </p>
          </div>

          <div className="w-full h-px bg-gradient-to-r from-transparent via-white/10 to-transparent my-4"></div>

          <p className="text-zinc-400 italic text-sm md:text-base max-w-2xl mx-auto leading-relaxed">
            <strong className="text-zinc-300 not-italic">P.S.</strong> The window of opportunity is not measured in years, but in days. When the final phase triggers, the paper in your bank account will revert to its intrinsic value: zero. Do not wait for the broadcast. Act now.
          </p>
        </div>
      </footer>

    </div>
  );
}
